import { Component } from '@angular/core';

@Component({
  selector: 'app-website-info',
  templateUrl: './website-info.component.html',
  styleUrls: ['./website-info.component.css']
})
export class WebsiteInfoComponent {
  /*infoList: string[] = [
    "Jesteśmy stroną non-profit, chcemy z pasją dzielić się najlepszymi według nas grami i wspierać gry niezależne, które zasługują na więcej rozgłosu.",
    "Nie jesteśmy właścicielami żadnej z gier znajdujących się na tej stronie. Wszelkie prawa należą do ich odpowiednich właścicieli."
  ];*/
}
